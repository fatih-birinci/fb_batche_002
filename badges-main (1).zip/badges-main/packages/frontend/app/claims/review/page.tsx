export default function Page() {
    return <div>Review claims page</div>
}