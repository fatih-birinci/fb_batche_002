export default function Page() {
    return <div>Manage claims page</div>
}