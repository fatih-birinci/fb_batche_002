export default function Page() {
    return <div>Dashboard page</div>
}