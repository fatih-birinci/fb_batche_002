export default function Page() {
    return <div>Badges page</div>
}