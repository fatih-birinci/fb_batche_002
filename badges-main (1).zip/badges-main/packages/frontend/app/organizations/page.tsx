export default function Page() {
    return <div>Organizations-Groups page</div>
}