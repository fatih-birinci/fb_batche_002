export default function Page() {
    return <div>Users page</div>
}