export default function Page() {
    return <div>Reporting claims page</div>
}