export default function Page() {
    return <div>Reporting social page</div>
}