export default function Page() {
    return <div>Reporting detail page</div>
}