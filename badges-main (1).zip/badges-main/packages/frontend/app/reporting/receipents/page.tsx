export default function Page() {
    return <div>Reporting receipents page</div>
}