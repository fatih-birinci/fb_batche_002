export default function Page() {
    return <div>Badge issuers page</div>
}