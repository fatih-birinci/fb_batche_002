export default function Page() {
    return <div>Issuing badge with users page</div>
}