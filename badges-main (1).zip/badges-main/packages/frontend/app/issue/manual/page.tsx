export default function Page() {
    return <div>Issuing badge manually page</div>
}