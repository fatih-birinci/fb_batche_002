export default function Page() {
    return <div>Issuing badge API page</div>
}