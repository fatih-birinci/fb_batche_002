export default function Page() {
    return <div>Rule based issuing page</div>
}