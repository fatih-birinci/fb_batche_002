export default function Page() {
    return <div>Issuing badge with groups page</div>
}