export default function Page() {
    return <div>Issuing badges with importing file page</div>
}