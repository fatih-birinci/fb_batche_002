export const mockUser = { id: '1', email: 'test@example.com', password: 'hashedPassword' };
export const mockRole = { id: '1', name: 'admin' };
export const mockPermission = { id: '1', name: 'read' };
